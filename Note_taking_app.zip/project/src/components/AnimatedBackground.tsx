import React, { useEffect, useState } from 'react';

interface Bubble {
  id: number;
  x: number;
  y: number;
  size: number;
  speed: number;
}

export const AnimatedBackground: React.FC = () => {
  const [bubbles, setBubbles] = useState<Bubble[]>([]);

  useEffect(() => {
    const createBubble = (): Bubble => ({
      id: Math.random(),
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 15 + 5,
      speed: Math.random() * 20 + 10,
    });

    const initialBubbles = Array.from({ length: 15 }, createBubble);
    setBubbles(initialBubbles);

    const animateBubbles = () => {
      setBubbles(prev => prev.map(bubble => ({
        ...bubble,
        y: bubble.y - (bubble.speed / 1000),
        x: bubble.x + Math.sin(bubble.y) * 0.1,
      })).map(bubble => bubble.y < -10 ? { ...createBubble(), y: 110 } : bubble));
    };

    const intervalId = setInterval(animateBubbles, 50);
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {bubbles.map(bubble => (
        <div
          key={bubble.id}
          className="absolute rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm"
          style={{
            left: `${bubble.x}%`,
            top: `${bubble.y}%`,
            width: `${bubble.size}rem`,
            height: `${bubble.size}rem`,
            transition: 'all 0.5s ease-out',
          }}
        />
      ))}
    </div>
  );
};