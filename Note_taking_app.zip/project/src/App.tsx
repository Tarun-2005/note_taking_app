import React, { useState } from 'react';
import { PlusCircle, Trash2, Edit3, Save, Search, StickyNote } from 'lucide-react';
import { AnimatedBackground } from './components/AnimatedBackground';

interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: Date;
}

function App() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredNotes = notes.filter(note =>
    note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    note.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const createNote = () => {
    if (!title.trim() || !content.trim()) return;

    const newNote: Note = {
      id: Date.now().toString(),
      title: title.trim(),
      content: content.trim(),
      createdAt: new Date(),
    };

    setNotes([newNote, ...notes]);
    setTitle('');
    setContent('');
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(note => note.id !== id));
  };

  const startEditing = (note: Note) => {
    setEditingId(note.id);
    setTitle(note.title);
    setContent(note.content);
  };

  const saveEdit = () => {
    if (!editingId || !title.trim() || !content.trim()) return;

    setNotes(notes.map(note =>
      note.id === editingId
        ? { ...note, title: title.trim(), content: content.trim() }
        : note
    ));
    setEditingId(null);
    setTitle('');
    setContent('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500/20 via-purple-500/20 to-pink-500/20 p-6 relative">
      <AnimatedBackground />
      
      <div className="max-w-6xl mx-auto relative">
        <div className="flex items-center justify-center gap-3 mb-12">
          <StickyNote className="w-8 h-8 text-indigo-600" />
          <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
            Notes
          </h1>
        </div>

        <div className="bg-white/40 backdrop-blur-xl rounded-2xl shadow-xl p-8 mb-12 transition-all duration-300 hover:shadow-2xl border border-white/50">
          <input
            type="text"
            placeholder="Note Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full mb-4 px-6 py-3 text-lg border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 bg-white/30 backdrop-blur-sm"
          />
          <textarea
            placeholder="Write your note here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full h-40 mb-6 px-6 py-4 text-lg border border-white/20 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 bg-white/30 backdrop-blur-sm"
          />
          <button
            onClick={editingId ? saveEdit : createNote}
            className="flex items-center justify-center w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-xl text-lg font-medium hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98] shadow-lg"
          >
            {editingId ? (
              <>
                <Save className="w-5 h-5 mr-2" />
                Save Changes
              </>
            ) : (
              <>
                <PlusCircle className="w-5 h-5 mr-2" />
                Create Note
              </>
            )}
          </button>
        </div>

        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-600 w-5 h-5" />
          <input
            type="text"
            placeholder="Search notes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-6 py-3 bg-white/40 backdrop-blur-xl border border-white/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300"
          />
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredNotes.length === 0 ? (
            <div className="col-span-full text-center py-12 bg-white/30 backdrop-blur-xl rounded-2xl border border-white/50">
              <StickyNote className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-xl text-gray-600">No notes found. Start creating!</p>
            </div>
          ) : (
            filteredNotes.map(note => (
              <div
                key={note.id}
                className="group bg-white/40 backdrop-blur-xl rounded-xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:scale-[1.02] border border-white/50"
              >
                <div className="flex justify-between items-start mb-4">
                  <h2 className="text-xl font-semibold text-gray-900 line-clamp-1">{note.title}</h2>
                  <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button
                      onClick={() => startEditing(note)}
                      className="text-indigo-600 hover:text-indigo-800 p-1 rounded-lg hover:bg-white/50 transition-colors"
                      title="Edit note"
                    >
                      <Edit3 className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => deleteNote(note.id)}
                      className="text-red-600 hover:text-red-800 p-1 rounded-lg hover:bg-white/50 transition-colors"
                      title="Delete note"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <p className="text-gray-700 whitespace-pre-wrap line-clamp-4 mb-4">{note.content}</p>
                <p className="text-sm text-gray-600">
                  {new Date(note.createdAt).toLocaleDateString(undefined, {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default App;